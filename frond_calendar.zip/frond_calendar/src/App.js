import React from 'react';
import Calendar from './pages/plan/Calendar';

const App = () => {
  return (
    <Calendar />
  );
}

export default App;