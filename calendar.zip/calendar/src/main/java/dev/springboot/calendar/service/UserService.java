package dev.springboot.calendar.service;

import dev.springboot.calendar.models.User;


public interface UserService {
     void userRegister(User user);
}
